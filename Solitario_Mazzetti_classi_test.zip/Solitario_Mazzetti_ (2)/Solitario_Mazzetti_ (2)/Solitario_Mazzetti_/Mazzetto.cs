﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SolitarioMazzetti__ProjectWork_
{
    public class Mazzetto
    {
        private List<Carta> _carte;
        private int _indice;
        private bool _mazzoCompletato;

        public List<Carta> Carte
        {
            get { return _carte; }
        }
        public int Indice
        {
            get { return _indice; }
            set
            {
                if (value < 0 || value >= 11) throw new ArgumentOutOfRangeException("non esiste un mazzetto con questo indice");
                _indice = value;
            }
        }
        public bool MazzoCompletato
        {
            get { return _mazzoCompletato; }
            set
            {
                foreach(Carta c in _carte)
                {
                    if(c.CartaCoperta==true) 
                    {
                        value = true;
                    }
                    else
                    {
                        value=false;
                        break;
                    }
                }
                _mazzoCompletato = value;
            }
        }
        public Mazzetto(int indice) 
        {
            Indice = indice;
            _carte = new List<Carta>();
        }
        //controlla se il valore della carta da aggiungere è uguale a quello del mazzetto
        private bool ControllaUguaglianzaValore(Carta c)
        {
           bool uguaglianzaValore = true;
            if(c.Valore!=Indice)
            {
                uguaglianzaValore = false;
            }
            return uguaglianzaValore;
        }
        //se la carta è uguale al valore la aggiungo se no mando un errore
        public void AggiungiCarta(Carta carta)
        {
            if (ControllaUguaglianzaValore(carta) == true)
            {
                _carte.Add(carta);
            }
            else
            {
                throw new Exception("il valore della carta non è uguale all'indice del mazzetto");
            }      
        }

        //sposto tutte le carte di uno ed elimino l'ultima carta
        private void RiodinaMazzetto()
        {
            for(int i= 1; i < Carte.Count;i++) 
            {
                _carte[i - 1] = _carte[i];
            }
            _carte.Remove(_carte[_carte.Count]);      
        }

        // rimuovi la prima carta e riodini il mazzetto
        public Carta EstraiPrimaCarta()
        {
            Carta primaCarta = _carte[0];
            _carte.Remove(_carte[0]);
            RiodinaMazzetto();
            return primaCarta;
        }

        public bool ContieneRe()
        {
            if (Carte.Count != 4)
            {
                return false;
            }
            else
            {
                if (Carte[0].Valore == 10 && Carte[1].Valore == 10 && Carte[2].Valore == 10 && Carte[3].Valore == 10)
                {
                    return true;
                }
            }
            return false;
        }
    }
}