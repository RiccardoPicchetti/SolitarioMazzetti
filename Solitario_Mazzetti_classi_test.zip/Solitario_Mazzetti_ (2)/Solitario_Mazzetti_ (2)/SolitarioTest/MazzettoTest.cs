﻿using SolitarioMazzetti__ProjectWork_;
namespace SolitarioTest
{
    [TestClass]
    public class MazzettoTest
    {
        [TestMethod]
        public void Indice_Invalido()
        {
            Mazzetto mazzettoTest = new Mazzetto(1);
            Assert.ThrowsException<System.ArgumentOutOfRangeException>(() => mazzettoTest.Indice = 12);
        }
        [TestMethod]
        public void ContieneRe_CorrettezzaTrue()
        {
            Mazzetto mazzettoTest = new Mazzetto(10);
            Carta reSpade = new Carta(10, Semi.Spade);
            Carta reBastoni = new Carta(10, Semi.Bastoni);
            Carta reCoppe = new Carta(10, Semi.Coppe);
            Carta reDenari = new Carta(10, Semi.Denari);
            mazzettoTest.Carte.Add(reSpade);
            mazzettoTest.Carte.Add(reBastoni);
            mazzettoTest.Carte.Add(reCoppe);
            mazzettoTest.Carte.Add(reDenari);
            Assert.AreEqual(true, mazzettoTest.ContieneRe());
        }
        [TestMethod]
        public void ContieneRe_CorrettezzaFalse()
        {
            Mazzetto mazzettoTest = new Mazzetto(10);
            Carta reSpade = new Carta(10, Semi.Spade);
            Carta bastone = new Carta(1, Semi.Bastoni);
            Carta reCoppe = new Carta(10, Semi.Coppe);
            Carta reDenari = new Carta(10, Semi.Denari);
            mazzettoTest.Carte.Add(reSpade);
            mazzettoTest.Carte.Add(bastone);
            mazzettoTest.Carte.Add(reCoppe);
            mazzettoTest.Carte.Add(reDenari);
            Assert.AreEqual(false, mazzettoTest.ContieneRe());
        }
    }
}