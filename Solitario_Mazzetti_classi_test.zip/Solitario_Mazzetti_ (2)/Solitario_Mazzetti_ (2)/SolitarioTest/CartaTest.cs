using SolitarioMazzetti__ProjectWork_;
namespace SolitarioTest
{
    [TestClass]
    public class CartaTest
    {
        [TestMethod]
        public void Valore_Invalido()
        {
            Carta cartaTest = new Carta(1, Semi.Spade);
            Assert.ThrowsException<System.ArgumentOutOfRangeException>(() => cartaTest.Valore=0);
        }
    }
}