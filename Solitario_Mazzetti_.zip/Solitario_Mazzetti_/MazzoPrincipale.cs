﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SolitarioMazzetti__ProjectWork_
{
    public class MazzoPrincipale
    {
        private Carta[] _mazzo;
        private List<Mazzetto> _mazzetti;

        public Carta[] Mazzo
        {
            get { return _mazzo; }          
        }

        public MazzoPrincipale()
        {
            _mazzo = new Carta[40];
            _mazzetti = new List<Mazzetto>();
            InizializzaMazzo();
            MescolaMazzo();
            CreaMazzetti();               
        }
        private void InizializzaMazzo()
        {
            for (int i = 0; i < 4; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    _mazzo[i * 10 + j - 1] = new Carta(j, (Semi)i);
                }
            }
        }

        private void MescolaMazzo()
        {
            Random random = new Random();

            for (int i = 0; i < _mazzo.Length; i++)
            {
                int posizioneRandom = random.Next(_mazzo.Length);               
                Carta tmp = _mazzo[posizioneRandom];
                _mazzo[posizioneRandom] = _mazzo[i];
                _mazzo[i] = tmp;
            }
            
        }

        private  void CreaMazzetti()
        {
            int indice = 10;
            for(int i =0; i<indice;i--)
            {
                _mazzetti.Add(new Mazzetto(i));
            }
            DistribuisciCarte();
        }

        private void DistribuisciCarte()
        {
            int indice = 0;
            for( int i = 0; i <_mazzo.Length-4;i++)
            {               
                _mazzetti[indice].AggiungiCarta(_mazzo[i]);
                indice++;
                if (indice == 10)
                {
                    indice = 0;
                }              
            }          
        }
    }
}