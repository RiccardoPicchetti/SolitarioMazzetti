﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SolitarioMazzetti__ProjectWork_
{
    public class Mazzetto
    {
        private List<Carta> _carte;
        private int _indice;

        public List<Carta> Carte
        {
            get { return _carte; }
        }

        

        public int Indice
        {
            get { return _indice; }
            set
            {
                if (value < 0 || value > 11) throw new ArgumentOutOfRangeException("non esiste un mazzetto con questo indice");
                _indice = value;
            }
        }

        public Mazzetto(int indice) 
        {
            Indice = indice;
            _carte = new List<Carta>();
        }
        public bool ControllaUguaglianzaValore()
        {
            bool uguaglianza = false;
            int valore = Indice;
            foreach (Carta c in Carte) 
            {
                if(c.Valore!=valore)
                {
                    uguaglianza = false;
                    break;
                }
                else
                {
                    uguaglianza = true;
                }
            }
            return uguaglianza;
        }

        public void AggiungiCarta(Carta carta)
        {
            _carte.Add(carta);
        }

        private void RiodinaMazzetto()
        {
            for(int i= 1; i < Carte.Count;i++) 
            {
                _carte[i - 1] = _carte[i];
            }
            _carte.Remove(_carte[_carte.Count]);      
        }
        public void RimuoviCarta()
        {
            _carte.Remove(Carte[0]);
            RiodinaMazzetto();
        }
        public Carta EstraiPrimaCarta()
        {
            Carta primaCarta = _carte[0];
            _carte.Remove(_carte[0]);
            return primaCarta;
        }


    }
}