﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SolitarioMazzetti__ProjectWork_
{
    public enum Semi
    {
        Bastoni,
        Spade,
        Coppe,
        Denari
    }
    public class Carta
    {
        private int _valore;
        private Semi _seme;
        private bool _cartaCoperta;

        public Semi Seme
        {
            get { return _seme; }
            set
            {
                if ((int)value < 0 || (int)value > 3) throw new ArgumentOutOfRangeException("il seme non è accettabile");
            }
        }

        public int Valore
        {
            get { return _valore; }
            set
            {
                if(value < 0 || value>10) throw new ArgumentOutOfRangeException("il valore non è accettabile");
            }
        }
        public bool CartaCoperta
        {
            get { return _cartaCoperta; }
            set
            {
                _cartaCoperta = value;
            }
        }
        public void GiraCarta()
        {
            if(CartaCoperta==true)
            {
                CartaCoperta = false;
            }
            else
            {
                CartaCoperta = true;
            }
        }

        public Carta(int valore, Semi seme )
        {
            Valore = valore;
            Seme = seme;
            CartaCoperta = false;     
        }
    }
}