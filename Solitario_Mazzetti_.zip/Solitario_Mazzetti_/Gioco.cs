﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SolitarioMazzetti__ProjectWork_
{
    public enum CondizionePartita
    {
        Vittoria,
        Sconfitta,
        In_Corso
    }
    public class Gioco
    {
        private MazzoPrincipale _mazzo;
        private CondizionePartita _condizionePartita;

        public void ControllaSituazionePartita()
        {
            throw new System.NotImplementedException();
        }
        public void CambiaPosizioneCarta()
        {
            throw new System.NotImplementedException();
        }



    }
}