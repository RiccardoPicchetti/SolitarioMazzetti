﻿namespace Solitario_Mazzetti_
{
    public class Class1
    {
        
    }
}