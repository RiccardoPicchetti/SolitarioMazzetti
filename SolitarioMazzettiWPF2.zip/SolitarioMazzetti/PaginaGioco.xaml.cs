﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SolitarioMazzetti
{
    /// <summary>
    /// Logica di interazione per PaginaGioco.xaml
    /// </summary>
    public partial class PaginaGioco : Page
    {
        public PaginaGioco()
        {
            InitializeComponent();
            btnReplay.Visibility = Visibility.Collapsed;
            btnDeck1.IsEnabled = false;
            btnDeck2.IsEnabled = false;
            btnDeck3.IsEnabled = false;
            btnDeck4.IsEnabled = false;
            btnDeck5.IsEnabled = false;
            btnDeck6.IsEnabled = false;
            btnDeck7.IsEnabled = false;
            btnDeck8.IsEnabled = false;
            btnDeck9.IsEnabled = false;
        }

        private void btnDeck_Click(object sender, RoutedEventArgs e)
        {
            // estrai prima carta e poi 
        }

        public void FindCard(Carta carta)
        {
            if (carta.Seme==Seme.Denara) 
            {
                if (carta.Valore == 1)
                {
                    imgDiscoveredCard.
                }
                if (carta.Valore==2)
                {
                    img2Denara.Visibility = Visibility.Visible;
                }
                if (carta.Valore == 3)
                {
                    img3Denara.Visibility = Visibility.Visible;
                }
                if (carta.Valore == 4)
                {
                    img4Denara.Visibility = Visibility.Visible;
                }
                if (carta.Valore == 5)
                {
                    img5Denara.Visibility = Visibility.Visible;
                }
                if (carta.Valore == 6)
                {
                    img6Denara.Visibility = Visibility.Visible;
                }
                if (carta.Valore == 7)
                {
                    img7Denara.Visibility = Visibility.Visible;
                }
                if (carta.Valore == 8)
                {
                    img8Denara.Visibility = Visibility.Visible;
                }
                if (carta.Valore == 9)
                {
                    img9Denara.Visibility = Visibility.Visible;
                }
                if (carta.Valore == 10)
                {
                    img10Denara.Visibility = Visibility.Visible;
                }
            }
        }
    }
}
