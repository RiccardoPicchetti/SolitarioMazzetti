﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolitarioMazzetti
{
    public class MazzoPrincipale
    {
        private Carta[] _mazzo;
        private List<Mazzetto> _mazzetti;

        public Carta[] Mazzo
        {
            get { return _mazzo; }
            set { _mazzo = value; }
        }
        public List<Mazzetto> Mazzetti
        {
            get { return _mazzetti; }
        }
        public MazzoPrincipale()
        {
            Mazzo = new Carta[40];
            InizializzaMazzo();
            MescolaMazzo();
            _mazzetti = CreaMazzetti();
        }
        private void InizializzaMazzo()
        {
            for (int i = 0; i < 4; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    Mazzo[i * 10 + j - 1] = new Carta(j, (Semi)i);
                }
            }
        }
        private void MescolaMazzo()
        {
            Random random = new Random();

            for (int i = 0; i < _mazzo.Length; i++)
            {
                int posizioneRandom = random.Next(Mazzo.Length);
                Carta tmp = _mazzo[posizioneRandom];
                Mazzo[posizioneRandom] = Mazzo[i];
                Mazzo[i] = tmp;
            }
        }
        //creo una lista di 10 mazzetti e richiamo il metodo DistribuisciCarte
        private List<Mazzetto> CreaMazzetti()
        {
            List<Mazzetto> mazzetti = new List<Mazzetto>();
            for (int i = 0; i < 11; i++) mazzetti.Add(new Mazzetto(i));
            DistribuisciCarte(mazzetti);
            return mazzetti;
        }

        //distribuisci le 40 carte del mazzo(una alla volta) per i 10 mazzetti
        private void DistribuisciCarte(List<Mazzetto> mazzetti)
        {
            int indice = 0;
            for (int i = 0; i < _mazzo.Length; i++)
            {

                mazzetti[indice].AggiungiInizialmenteCarta(Mazzo[i]);
                indice++;
                if (indice == 10)
                {
                    indice = 0;
                }
            }
        }

        public bool Vittoria()
        {
        bool vittoria = true;
        foreach (Mazzetto m in _mazzetti)
        {
            if (m.MazzoCompletato == false)
            {
                vittoria = false;
                break;
            }
        }
        return vittoria;
        }

        public bool Sconfitta()
        {

            if (Mazzetti[10].Carte.Count == 5)
            {
                return true;
            }
            else
            {
                if (ContieneRe(Mazzetti[10]))
                {
                    return true;
                }
            }

            return false;
        }

        private bool ContieneRe(Mazzetto mazzeto)
        {
            if (mazzeto.Carte.Count != 4)
            {
                return false;
            }
            else
            {
                if (mazzeto.Carte[0].Valore == 10 && mazzeto.Carte[1].Valore == 10 && mazzeto.Carte[2].Valore == 10 && mazzeto.Carte[3].Valore == 10)
                {
                    return true;
                }
            }

            return false;
        }

        public bool In_Corso()
        {
            bool in_corso = false;

            if ((Vittoria() == false) && (Sconfitta() == false))
            {
                in_corso = true;
            }
            return in_corso;
        }

    }
}

