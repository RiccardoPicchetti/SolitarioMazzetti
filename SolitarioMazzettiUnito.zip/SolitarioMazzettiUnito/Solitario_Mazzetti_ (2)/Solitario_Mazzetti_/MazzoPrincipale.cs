﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SolitarioMazzetti__ProjectWork_
{
    public class MazzoPrincipale
    {
        private Carta[] _mazzo;
        private List<Mazzetto> _mazzetti;

        public Carta[] Mazzo
        {
            get { return _mazzo; }          
        }
        public List<Mazzetto> Mazzetti
        {
            get { return _mazzetti; }
        }
        public MazzoPrincipale()
        {
            _mazzo = new Carta[40]; 
            InizializzaMazzo();
            MescolaMazzo();
            _mazzetti=CreaMazzetti();               
        }
        private void InizializzaMazzo()
        {
            for (int i = 0; i < 4; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    _mazzo[i * 10 + j - 1] = new Carta(j, (Semi)i);
                }
            }
        }
        private void MescolaMazzo()
        {
            Random random = new Random();

            for (int i = 0; i < _mazzo.Length; i++)
            {
                int posizioneRandom = random.Next(_mazzo.Length);               
                Carta tmp = _mazzo[posizioneRandom];
                _mazzo[posizioneRandom] = _mazzo[i];
                _mazzo[i] = tmp;
            }           
        }
        //creo una lista di 10 mazzetti e richiamo il metodo DistribuisciCarte
        private List<Mazzetto> CreaMazzetti()
        {
            List<Mazzetto> mazzetti= new List<Mazzetto>(10);
            DistribuisciCarte();
            return mazzetti;
        }

        //distribuisci le 40 carte del mazzo(una alla volta) per i 10 mazzetti
        private void DistribuisciCarte()
        {
            int indice = 0;
            for( int i = 0; i <_mazzo.Length-4;i++)
            {               
                _mazzetti[indice].AggiungiCarta(_mazzo[i]);
                indice++;
                if (indice == 10)
                {
                    indice = 0;
                }              
            }          
        }

        public bool Vittoria()
        {
            bool vittoria=true;
            foreach(Mazzetto m in _mazzetti) 
            {
                if(m.MazzoCompletato==false)
                {
                    vittoria = false; 
                    break;
                }
            }
            return vittoria;
        }

        public bool Sconfitta()
        {

            if (Mazzetti[10].Carte.Count == 5)
            {
                return true;
            }
            else
            {
                if (ContieneRe(Mazzetti[10]))
                {
                    return true;
                }
            }

            return false;
        }

        private bool ContieneRe(Mazzetto mazzeto)
        {
            if (mazzeto.Carte.Count != 4)
            {
                return false;
            }
            else
            {
                if (mazzeto.Carte[0].Valore == 10 && mazzeto.Carte[1].Valore == 10 && mazzeto.Carte[2].Valore == 10 && mazzeto.Carte[3].Valore == 10)
                {
                    return true;
                }
            }

            return false;
        }

        public bool In_Corso()
        {
            bool in_corso = false;

            if ((Vittoria() ==false ) && (Sconfitta() ==false))
            {
                in_corso = true;
            }
            return in_corso;
        }

    }
}